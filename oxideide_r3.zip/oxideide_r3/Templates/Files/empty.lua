﻿PLUGIN.Title = ""
PLUGIN.Description = ""

function PLUGIN:Init()
	
end